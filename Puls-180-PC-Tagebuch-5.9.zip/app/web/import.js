const file = document.querySelector('#datei');
const profile = document.querySelector('#profil');
const preview = document.querySelector('#vorschau');
const message = document.querySelector('#meldung');
const confirmButton = document.querySelector('#importieren');
let selectedPackage = null;
let checkedProfile = null;

async function loadNames() {
  try {
    const response = await fetch('/api/profiles', {cache: 'no-store'});
    const data = await response.json();
    if (!response.ok) throw Error(data.error || 'Benutzer konnten nicht geladen werden.');
    for (const item of data.profiles || []) {
      const option = profile.querySelector(`option[value="${item.profile}"]`);
      if (option) option.textContent = item.name;
    }
  } catch (error) { message.textContent = error.message; }
}

function reset() { selectedPackage = null; checkedProfile = null; confirmButton.hidden = true; preview.textContent = ''; message.textContent = ''; }
file.addEventListener('change', reset);
profile.addEventListener('change', reset);

async function send(commit) {
  const response = await fetch('/api/measurement-import', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({package: selectedPackage, profile: profile.value, commit})
  });
  const data = await response.json();
  if (!response.ok) throw Error(data.error || 'Datei konnte nicht gelesen werden.');
  return data;
}

document.querySelector('#pruefen').addEventListener('click', async () => {
  reset();
  try {
    if (!file.files.length) throw Error('Bitte zuerst eine Datei auswählen.');
    if (file.files[0].size > 2000000) throw Error('Datei ist zu groß.');
    selectedPackage = JSON.parse(await file.files[0].text());
    const data = await send(false);
    checkedProfile = profile.value;
    preview.textContent = `Datei von ${data.sourceName}: ${data.count} Werte. Ziel im PC: ${profile.selectedOptions[0].textContent}. Neu: ${data.new}, schon vorhanden: ${data.duplicates}.`;
    confirmButton.hidden = data.new === 0;
    if (data.new === 0) message.textContent = 'Alle Werte sind bereits vorhanden.';
  } catch (error) { reset(); message.textContent = error.message; }
});

confirmButton.addEventListener('click', async () => {
  if (!selectedPackage || checkedProfile !== profile.value) return reset();
  confirmButton.disabled = true;
  try {
    const data = await send(true);
    message.textContent = `${data.added} Werte importiert. Du kannst zum Tagebuch zurückkehren und auf Aktualisieren drücken.`;
    confirmButton.hidden = true;
  } catch (error) { message.textContent = error.message; }
  finally { confirmButton.disabled = false; }
});
loadNames();
