"""Validated, additive restore for local Puls 180 PC diary JSON backups."""
import base64, datetime, json, uuid
from month_folders import schema

MAX_BACKUP = 50 * 1024 * 1024
MAX_ROWS = 10000
MAX_FILES_TOTAL = 40 * 1024 * 1024

def _reading(row):
 if not isinstance(row,dict): raise ValueError('Messdaten ungültig.')
 rid=str(uuid.UUID(row['id']))
 sys,dia=row['systolic'],row['diastolic'];pulse=row.get('pulse')
 if type(sys) is not int or type(dia) is not int or not 0<dia<sys<=400 or dia>300: raise ValueError('Messdaten ungültig.')
 if pulse is not None and (type(pulse) is not int or not 0<pulse<=300): raise ValueError('Puls ungültig.')
 dt=datetime.datetime.fromisoformat(str(row['measuredAt']).replace('Z','+00:00'))
 if dt.tzinfo is None or not 0<=dt.timestamp()<=datetime.datetime.now().timestamp()+300: raise ValueError('Messzeit ungültig.')
 note=row.get('note','')
 if not isinstance(note,str) or len(note)>1000: raise ValueError('Notiz ungültig.')
 origin=row.get('origin','phone')
 if origin not in ('phone','pc'): raise ValueError('Herkunft ungültig.')
 profile=str(row.get('profile','1'));profile_name=str(row.get('profileName','Kubi')).strip()[:40]
 if profile not in ('1','2') or not profile_name: raise ValueError('Benutzer ungültig.')
 hidden=1 if row.get('hidden') else 0
 return rid,sys,dia,pulse,dt.astimezone(datetime.timezone.utc).isoformat(),note,origin,profile,profile_name,hidden

def handle(h,connection):
 try:
  size=int(h.headers.get('Content-Length','0'))
  if not 0<size<=MAX_BACKUP or 'application/json' not in h.headers.get('Content-Type',''): raise ValueError('Bitte eine gültige JSON-Sicherung bis 50 MB wählen.')
  data=json.loads(h.rfile.read(size))
  readings=data.get('readings');assignments=data.get('monthAssignments',[]);files=data.get('monthFiles',[])
  if not isinstance(readings,list) or len(readings)>MAX_ROWS or not isinstance(assignments,list) or not isinstance(files,list): raise ValueError('Sicherungsdatei ungültig.')
  clean=[_reading(row) for row in readings]
  clean_assign=[]
  for item in assignments:
   rid=str(uuid.UUID(item['id']));year=item['year'];month=item['month']
   if type(year) is not int or not 1970<=year<=2200 or type(month) is not int or not 1<=month<=12: raise ValueError('Monatszuordnung ungültig.')
   clean_assign.append((rid,year,month))
  clean_files=[];total=0
  for item in files:
   fid=str(uuid.UUID(item['id']));year=item['year'];month=item['month'];name=item['name']
   if type(year) is not int or not 1970<=year<=2200 or type(month) is not int or not 1<=month<=12 or not isinstance(name,str) or not 1<=len(name)<=160: raise ValueError('Monatsdatei ungültig.')
   body=base64.b64decode(item['body'],validate=True);total+=len(body)
   if total>MAX_FILES_TOTAL: raise ValueError('Monatsdateien sind zu groß.')
   clean_files.append((fid,year,month,name,body))
  added=0
  with connection() as c:
   schema(c)
   for rid,sys,dia,pulse,measured,note,origin,profile,profile_name,hidden in clean:
    before=c.total_changes
    c.execute('INSERT OR IGNORE INTO readings(id,systolic,diastolic,pulse,measuredAt,note,origin,profile,profileName) VALUES(?,?,?,?,?,?,?,?,?)',(rid,sys,dia,pulse,measured,note,origin,profile,profile_name))
    if c.total_changes>before: added+=1
    c.execute('INSERT OR IGNORE INTO ui_state(id,hidden,note) VALUES(?,?,?)',(rid,hidden,note))
   existing={r[0] for r in c.execute('SELECT id FROM readings')}
   for item in clean_assign:
    if item[0] in existing:c.execute('INSERT OR IGNORE INTO month_assignment(id,year,month) VALUES(?,?,?)',item)
   for item in clean_files:c.execute('INSERT OR IGNORE INTO month_files(id,year,month,name,body) VALUES(?,?,?,?,?)',item)
  return h.reply({'ok':True,'added':added,'readings':len(clean),'files':len(clean_files)})
 except (ValueError,KeyError,TypeError,json.JSONDecodeError,base64.binascii.Error): return h.reply({'error':'Sicherungsdatei ungültig oder beschädigt.'},400)
 except Exception: return h.reply({'error':'Wiederherstellung fehlgeschlagen. Vorhandene Daten wurden nicht ersetzt.'},500)
