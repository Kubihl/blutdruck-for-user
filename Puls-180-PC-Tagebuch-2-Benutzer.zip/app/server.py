from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import sqlite3,json,uuid,datetime,os,webbrowser
ROOT=Path(__file__).parent
PORT=18775
from pairing_keys import DATA
DB=DATA/'tagebuch.sqlite'
from contextlib import contextmanager
@contextmanager
def connection():
 DB.parent.mkdir(exist_ok=True)
 c=sqlite3.connect(DB)
 c.execute('CREATE TABLE IF NOT EXISTS readings(id TEXT PRIMARY KEY,systolic INTEGER,diastolic INTEGER,pulse INTEGER,measuredAt TEXT,note TEXT)')
 if 'origin' not in [r[1] for r in c.execute('PRAGMA table_info(readings)')]:c.execute("ALTER TABLE readings ADD COLUMN origin TEXT NOT NULL DEFAULT 'pc'")
 c.execute('CREATE TABLE IF NOT EXISTS ui_state(id TEXT PRIMARY KEY,hidden INTEGER NOT NULL DEFAULT 0,note TEXT)')
 c.row_factory=sqlite3.Row
 try:
  yield c
  c.commit()
 except Exception:
  c.rollback();raise
 finally:c.close()
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def reply(self,data,status=200,kind='application/json; charset=utf-8',download=False,export_id=None):
  body=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
  if export_id:self.send_header('X-Export-Id',export_id)
  if download:self.send_header('Content-Disposition','attachment; filename="Blutdruck-Sicherung.json"')
  self.end_headers();self.wfile.write(body)
 def validhost(self):return self.headers.get('Host') in [f'127.0.0.1:{PORT}',f'localhost:{PORT}']
 def do_GET(self):
  if not self.validhost():return self.reply({'error':'Ungültiger Zugriff'},403)
  if self.path=='/pair':
   from wlan_sync import pairing_page
   return self.reply(pairing_page(),kind='text/html; charset=utf-8')
  if self.path=='/api/identity':return self.reply({'app':'blutdruck-sales-desktop'})
  if self.path=='/api/sync-status':
   from wlan_sync import sync_status
   return self.reply(sync_status())
  if self.path in ['/api/measurements','/api/backup']:
   if self.path=='/api/measurements':
    from wlan_sync import request_phone_sync
    request_phone_sync()
   from diary_actions import visible_rows
   with connection() as c:
    rows=visible_rows(c,include_hidden=self.path=='/api/backup');data={'readings':rows}
    if self.path=='/api/backup':
     from month_folders import schema
     import base64
     schema(c);data['monthAssignments']=[dict(r) for r in c.execute('SELECT * FROM month_assignment')]
     data['monthFiles']=[{**dict(r),'body':base64.b64encode(r['body']).decode()} for r in c.execute('SELECT * FROM month_files')]
   return self.reply(data,download=self.path=='/api/backup')
  names={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/datenschutz.html':'datenschutz.html','/anleitung.html':'anleitung.html','/anleitung.pdf':'anleitung.pdf'}
  if self.path not in names:return self.reply({'error':'Nicht gefunden'},404)
  file=ROOT/'web'/names[self.path];kind='text/html' if file.suffix=='.html' else 'text/css' if file.suffix=='.css' else 'application/pdf' if file.suffix=='.pdf' else 'text/javascript'
  self.reply(file.read_bytes(),kind=kind+'; charset=utf-8')
 def do_POST(self):
  if not self.validhost() or self.headers.get('Origin') not in [f'http://127.0.0.1:{PORT}',f'http://localhost:{PORT}']:return self.reply({'error':'Ungültiger Ursprung'},403)
  if self.path=='/api/open-bluetooth':
   try: os.startfile('ms-settings:bluetooth'); return self.reply({'message':'Windows-Bluetooth wurde geöffnet.'})
   except Exception: return self.reply({'error':'Windows-Bluetooth konnte nicht geöffnet werden.'},500)
  if self.path.startswith('/api/months/'):
   from month_folders import handle
   return handle(self,connection)
  if self.path in ['/api/action','/api/export','/api/open-with','/api/file-apps','/api/open-app','/api/share-file','/api/save-file']:
   from diary_actions import handle
   return handle(self,connection)
  if self.path!='/api/measurements':return self.reply({'error':'Nicht gefunden'},404)
  try:
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<=6000 or 'application/json' not in self.headers.get('Content-Type',''):raise ValueError()
   a=json.loads(self.rfile.read(n));uuid.UUID(a['id'])
   for key,maximum in [('systolic',400),('diastolic',300)]:
    if type(a[key]) is not int or not 1<=a[key]<=maximum:raise ValueError()
   if a['systolic']<=a['diastolic']:raise ValueError()
   if a['pulse'] is not None and (type(a['pulse']) is not int or not 1<=a['pulse']<=300):raise ValueError()
   if not isinstance(a['note'],str) or len(a['note'])>1000:raise ValueError()
   dt=datetime.datetime.fromisoformat(a['measuredAt'].replace('Z','+00:00'))
   if dt.tzinfo is None or dt.timestamp()<0 or dt.timestamp()>datetime.datetime.now().timestamp()+300:raise ValueError()
   a['measuredAt']=dt.astimezone(datetime.timezone.utc).isoformat()
  except Exception:return self.reply({'error':'Bitte Eingaben prüfen.'},400)
  try:
   with connection() as c:c.execute('INSERT OR IGNORE INTO readings(id,systolic,diastolic,pulse,measuredAt,note) VALUES(?,?,?,?,?,?)',tuple(a[k] for k in ['id','systolic','diastolic','pulse','measuredAt','note']))
   self.reply({'id':a['id']},201)
  except sqlite3.Error:self.reply({'error':'Speichern fehlgeschlagen.'},500)
if __name__=='__main__':
 try:server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
 except OSError:
  if '--open' in __import__('sys').argv:webbrowser.open(f'http://127.0.0.1:{PORT}')
  raise SystemExit()
 if '--open' in __import__('sys').argv:webbrowser.open(f'http://127.0.0.1:{PORT}')
 from pairing_keys import ensure_keys
 ensure_keys()
 from wlan_sync import start
 with connection():pass
 sync_server=start(connection)
 server.serve_forever()
