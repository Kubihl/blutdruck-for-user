@echo off
start "" "%~dp0USER-Tagebuch-Windows.exe"
