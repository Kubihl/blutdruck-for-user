@echo off
call "%~dp0Puls-180-PC-Tagebuch-STARTEN.cmd"
