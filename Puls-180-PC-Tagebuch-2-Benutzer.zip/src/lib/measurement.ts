export type Reading={id:string;systolic:number;diastolic:number;pulse:number|null;measuredAt:string;note:string};
export function validateReading(v:unknown):Reading{if(!v||typeof v!=='object')throw Error('Ungültige Messung.');const a=v as Record<string,unknown>;
if(typeof a.id!=='string'||!/^[0-9a-f-]{36}$/i.test(a.id))throw Error('Ungültige Kennung.');
for(const [key,max] of [['systolic',400],['diastolic',300]] as const){if(!Number.isInteger(a[key])||Number(a[key])<1||Number(a[key])>max)throw Error('Bitte gültige Blutdruckwerte eingeben.');}
if(Number(a.systolic)<=Number(a.diastolic))throw Error('Der obere Wert muss größer als der untere sein.');
if(a.pulse!==null&&(!Number.isInteger(a.pulse)||Number(a.pulse)<1||Number(a.pulse)>300))throw Error('Bitte den Puls prüfen.');
if(typeof a.measuredAt!=='string'||!Number.isFinite(Date.parse(a.measuredAt))||Date.parse(a.measuredAt)>Date.now()+300000||Date.parse(a.measuredAt)<0)throw Error('Bitte Datum und Uhrzeit prüfen.');
if(typeof a.note!=='string'||a.note.length>1000)throw Error('Notiz: höchstens 1000 Zeichen.');
return {id:a.id,systolic:Number(a.systolic),diastolic:Number(a.diastolic),pulse:a.pulse as number|null,measuredAt:new Date(a.measuredAt).toISOString(),note:a.note.trim()};}
