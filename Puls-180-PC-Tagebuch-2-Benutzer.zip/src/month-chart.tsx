type Point={month:number,count:number,systolic:number|null,diastolic:number|null,pulse:number|null};
const months=['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
const series=[{key:'systolic',name:'Systolisch',color:'#bb2438'},{key:'diastolic',name:'Diastolisch',color:'#145bc3'},{key:'pulse',name:'Puls',color:'#7440a6'}] as const;
export default function MonthChart({points,year}:{points:Point[],year:number}){
 const ordered=[...points].sort((a,b)=>a.month-b.month);
 if(!ordered.some(p=>p.count))return <p className="month-chart-empty">Für diese Auswahl liegen noch keine Messungen für ein Diagramm vor.</p>;
 const first=ordered[0].month,last=ordered[ordered.length-1].month;
 const x=(m:number)=>first===last?255:55+(m-first)/(last-first)*400;
 return <section className="month-chart"><h3>Diagramm der Auswahl · {year}</h3><p>Monatliche Durchschnittswerte</p>{(['pressure','pulse'] as const).map(kind=>{
  const lines=kind==='pressure'?series.slice(0,2):series.slice(2);
  const values=ordered.flatMap(p=>p.count?lines.map(s=>p[s.key]).filter((v):v is number=>v!==null):[]);
  if(!values.length)return <p key={kind}>Keine Pulswerte in dieser Auswahl.</p>;
  const low=Math.max(0,Math.floor((Math.min(...values)-10)/10)*10),high=Math.ceil((Math.max(...values)+10)/10)*10;
  const y=(v:number)=>155-(v-low)/(high-low)*120;
  return <div key={kind} className="month-chart-panel"><h4>{kind==='pressure'?'Blutdruck · mmHg':'Puls · bpm'}</h4><svg viewBox="0 0 490 192" role="img" aria-label={(kind==='pressure'?'Blutdruck':'Puls')+' – Monatsdurchschnitte der Auswahl'}>
   {[0,1,2,3,4].map(i=>{let v=low+(high-low)*i/4;return <g key={i}><line x1="55" x2="455" y1={y(v)} y2={y(v)} stroke="#d7e1ed"/><text x="45" y={y(v)+4} textAnchor="end" fontSize="12" fill="#405372">{Math.round(v)}</text></g>})}
   {ordered.map(p=><text key={p.month} x={x(p.month)} y="181" textAnchor="middle" fontSize="12" fill="#405372">{months[p.month-1]}</text>)}
   {lines.map(s=>{let previous:number|null=null;let path='';for(let p of ordered){let v=p.count?p[s.key]:null;if(v===null){previous=null;continue}path+=(previous!==null&&p.month===previous+1?' L ':' M ')+x(p.month)+' '+y(v);previous=p.month}return <g key={s.key}><path d={path} fill="none" stroke={s.color} strokeWidth="2.5" strokeDasharray={s.key==='diastolic'?'6 3':undefined}/>{ordered.filter(p=>p.count&&p[s.key]!==null).map(p=><circle key={p.month} cx={x(p.month)} cy={y(p[s.key]!)} r="4.5" fill={s.color} stroke="white" strokeWidth="1.5"><title>{months[p.month-1]}: {s.name} {p[s.key]} {kind==='pressure'?'mmHg':'bpm'}</title></circle>)}</g>})}
  </svg><div className="month-chart-legend">{lines.map(s=><span key={s.key}><i style={{background:s.color}}/>{s.name}</span>)}</div></div>
 })}<small>Nur gewählte Monate mit Messungen. Lücken werden nicht als Null dargestellt.</small></section>
}
