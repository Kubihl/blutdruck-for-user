@echo off
setlocal
set "ZIEL=%~dp0Puls-180-PC-Tagebuch-STARTEN.cmd"
set "ORDNER=%~dp0"
set "LINK=%USERPROFILE%\Desktop\Puls 180 - PC-Tagebuch.lnk"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut($env:LINK); $s.TargetPath=$env:ZIEL; $s.WorkingDirectory=$env:ORDNER; $s.Description='Puls 180 - PC-Tagebuch'; $s.Save()"
if exist "%LINK%" (
 echo.
 echo Desktop-Verknuepfung wurde erstellt.
) else (
 echo.
 echo Verknuepfung konnte nicht erstellt werden.
)
pause
