# Lokaler Teststand – 15.10.2026

PC-Tagebuch 5.11: kompakte Profilanzeige mit kleiner Schrift, standardmäßig zugeklappt; Gewichtsverlauf separat aufklappbar. Vier getrennte Benutzer. Profilangaben werden aus der Handydatei erst nach Prüfung und Bestätigung übernommen. Ältere Dateien ohne Profil bleiben verwendbar. Vorhandene neuere Gewichtsangaben bleiben beim Import alter Dateien erhalten.

Dazu gehört App 5.19: enthält Profil aus 5.18 und ergänzt die Profilangaben in PC-Dateien. Die Übernahme geschieht beim nächsten Dateiimport, nicht automatisch über das Netzwerk.

11 automatisierte Importprüfungen bestanden, darunter Vorschau ohne Profiländerung, Benutzertrennung, ungültige Profile, alte Dateien, doppelte und ältere Gewichtsangaben. JavaScript-Syntax geprüft. Android-Build und APK-v3-Signatur geprüft.
Bedienung und echte Übertragung auf dem Handy sind noch vom Benutzer zu prüfen. App 5.19 wurde noch nicht auf dem Testhandy installiert.
Keine Veröffentlichung und kein GitHub-Upload.
