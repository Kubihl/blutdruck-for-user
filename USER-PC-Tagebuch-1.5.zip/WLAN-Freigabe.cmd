@echo off
powershell.exe -NoProfile -Command "Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile -File ""%~dp0WLAN-Freigabe.ps1""'"
