$program = Join-Path $PSScriptRoot 'runtime\pythonw.exe'
if (!(Test-Path -LiteralPath $program)) { throw 'Tagebuch-Laufzeit fehlt.' }
if (!(Get-NetFirewallRule -DisplayName 'USER Tagebuch WLAN 18776' -ErrorAction SilentlyContinue)) {
New-NetFirewallRule -DisplayName 'USER Tagebuch WLAN 18776' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 18776 -Program $program -Profile Private -RemoteAddress LocalSubnet | Out-Null
}
